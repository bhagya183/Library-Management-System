package com.itvedant.library;

import java.sql.Connection;
import java.util.List;
import java.util.Scanner;

public class MainApp {
	
	public static void main(String[] args) {
		
		//Connection con = DBConnect.getConnection();
		
		//System.out.println(con);
				
		//DBConnect.closeConnection();
		
		Scanner sc = new Scanner(System.in);
		
		LibraryService lservice = new LibraryService();
		
		System.out.println("Welcome to Library Management System");
		
		while(true) {
			
			System.out.println();
			
			System.out.println("Kindly Enter your Choice: ");
			System.out.println("1. Add New Book.");
			System.out.println("2. View All Books.");
			System.out.println("3. Update Book.");
			System.out.println("4. Delete Book.");
			System.out.println("5. Search the Book.");
			System.out.println("6. Exit.");
			
			int userInput = sc.nextInt();
			
			if(userInput == 6) {
				break;
			}else {
				switch(userInput) {
					
					case 1: 
						
						System.out.println("Enter Id: ");
						int id = sc.nextInt();
						
						System.out.println("Enter Title: ");
						String title = sc.next();
						
						System.out.println("Enter Author: ");
						String author = sc.next();

						Boolean b = lservice.insertRecord(id, title, author);
						
						if(b) {
							
							System.out.println("Data Inserted.");

						}else {
							
							System.out.println("Data Not Inserted.");

						}
						
						break;
				
					case 2: 
						List<Book> books = lservice.readRecord();
						
						for(Book x : books) {
							
							System.out.println(x);
							
						}
						
						break;
						
					default:
						System.out.println("Invalid.");
						
						break;
						
					case 3:
						
						System.out.println("Enter Id: ");
						id = sc.nextInt();
						
						Book book = lservice.searchRecord(id);
						
						System.out.println(book);
						
						System.out.println("Enter the Choice for field which you want to Update.");
						
						System.out.println("a. title");
						System.out.println("b. author");
						
						char c = sc.next().charAt(0);
						
						switch(c) {
						
							case 'a' : 
										System.out.println("Enter he Title: ");
										title = sc.next();
										book.setTitle(title);
										break;
										
							case 'b' : 
										System.out.println("Enter he Author: ");
										author = sc.next();
										book.setAuthor(author);
										break;
										
							default: 
										System.out.println("Invalid Input.");
						}
						
						b = lservice.updateRecord(book);
						
						if(b) {
							
							System.out.println("Book Data Updated.");
							
						}else {
							
							System.out.println("Book Data Not Updated.");
							
						}
						
						break;
						
					case 4:
						
						System.out.println("Enter Id: ");
						id = sc.nextInt();
						
						b = lservice.deleteRecord(id);
						
						if(b) {
							System.out.println("Record Deleted.");
						}else {
							System.out.println("Record Not Deleted.");
						}
						
						break;
						
					case 5:
						
						System.out.println("Enter Id: ");
						id = sc.nextInt();
						
						Book bookss = lservice.searchRecord(id);
						
						System.out.println(bookss);

						break;
	
				}
			}
		}	
	}
}
