package com.itvedant.library;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

// This is POJO File

public class LibraryService {
	
	static Connection con = DBConnect.getConnection();
	
	// Add New Book
	public boolean insertRecord(int id, String title, String author) {
		
		String query = "insert into books values (?, ?, ?)";
		
		try {
			
			PreparedStatement ps = con.prepareStatement(query);
			
			ps.setInt(1, id);
			ps.setString(2, title);
			ps.setString(3, author);
			
			int i = ps.executeUpdate();
			
			if( i > 0) {
				return true;
			}
			
		}catch(Exception e) {
			System.out.println(e.getMessage());

		}
		
		return false;
	}
	
	//Read Record
	public List<Book> readRecord(){
		
		List<Book> books = new ArrayList<Book>(); 
		
		String query = "select * from books";
		
		try {
			
			Statement stats = con.createStatement();
			
			ResultSet rs = stats.executeQuery(query);
			
			while(rs.next()) {
				
				Book b = new Book();
				
				b.setId(rs.getInt("id"));
				b.setTitle(rs.getString("title"));
				b.setAuthor(rs.getString("author"));
				
				books.add(b);
				
			}
			
		}catch(Exception e) {
			
			System.out.println(e.getMessage());
		}
		
		return books;
	}
	
	// For Delete Book
	public boolean deleteRecord(int id) {
		
		String query = "delete from books where id = ?";
		
		try {
			
			PreparedStatement ps = con.prepareStatement(query);
			
			ps.setInt(1, id);
			
			int i = ps.executeUpdate();
			
			if(i > 0) {
				
				return true;
				
			}
			
		}catch(Exception e) {
			
			System.out.println(e.getMessage());
			
		}
		
		return false;
	}
	
	// Update Record
	public boolean updateRecord(Book b) {
		
		String query = "update books set title = ?, author = ? where id = ?";
		
		try {
			
			PreparedStatement ps = con.prepareStatement(query);
			
			ps.setString(1, b.getTitle());
			ps.setString(2, b.getAuthor());
			ps.setInt(3, b.getId());
			
			int i = ps.executeUpdate();
			
			if(i > 0) {
				
				return true;
				
			}
			
		}catch(Exception e) {
			
			System.out.println(e.getMessage());
		}
		
		return false;
	}
	
	
	// For Search the Record
	public Book searchRecord(int id) {
		
		Book b = new Book();
		
		String query = "select * from books where id = ?";
		
		try {
			
			PreparedStatement ps = con.prepareStatement(query);
			
			ps.setInt(1, id);
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				
				b.setId(rs.getInt("id"));
				b.setTitle(rs.getString("title"));
				b.setAuthor(rs.getString("author"));
			}
			
		}catch(Exception e) {
			
			System.out.println(e.getMessage());

		}
		
		return b;
	}
	
	
}
